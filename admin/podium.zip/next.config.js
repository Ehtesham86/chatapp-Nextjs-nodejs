// next.config.js
/** @type {import('next').NextConfig} */
const nextConfig = {
    images: {
      domains: ['m.media-amazon.com'], // Add your image domains here
    },
  };
  
  module.exports = nextConfig;

  
