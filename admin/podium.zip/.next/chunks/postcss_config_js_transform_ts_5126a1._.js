(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "chunks/postcss_config_js_transform_ts_5126a1._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "chunks/postcss_config_js_transform_ts_5126a1._.js",
  "chunks": [
    "chunks/node_modules_0b7313._.js",
    "chunks/_0b8f1c._.js"
  ],
  "source": "dynamic"
});
