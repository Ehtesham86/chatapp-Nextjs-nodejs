(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "chunks/[output]__next_transform_cc8fc1.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "chunks/[output]__next_transform_cc8fc1.js",
  "chunks": [
    "chunks/[turbopack-node]__a86098._.js",
    "chunks/postcss_config_js_transform_ts_b0fe12._.js"
  ],
  "source": "entry"
});
