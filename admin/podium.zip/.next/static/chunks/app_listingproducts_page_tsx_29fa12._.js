(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_listingproducts_page_tsx_29fa12._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_listingproducts_page_tsx_29fa12._.js",
  "chunks": [
    "static/chunks/node_modules_react-icons_fa_index_mjs_d2e2d7._.js",
    "static/chunks/node_modules_react-icons_fa6_index_mjs_00e856._.js",
    "static/chunks/node_modules_react-icons_lib_74ccc9._.js",
    "static/chunks/app_listingproducts_page_tsx_7101ee._.js"
  ],
  "source": "dynamic"
});
