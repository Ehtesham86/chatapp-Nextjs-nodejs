(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_layout_tsx_c4a6de._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_layout_tsx_c4a6de._.js",
  "chunks": [
    "static/chunks/node_modules_83605a._.js",
    "static/chunks/_e4e141._.js",
    "static/chunks/_815d8e._.css",
    "static/chunks/node_modules_b50e17._.js"
  ],
  "source": "dynamic"
});
